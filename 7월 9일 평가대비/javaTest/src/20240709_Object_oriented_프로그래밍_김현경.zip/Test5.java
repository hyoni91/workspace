package Test;


import java.util.Arrays;
import java.util.Scanner;

//요구사항
//1) 먼저 크기가 3인 정수형 배열을 생성하고 배열의 각 요소에 1 ~ 9사이의 랜덤한 정수를 저장한다.
// 중복 불허.
// 2) 3스트라이크가 될 때까지 프로그램을 지속되어야 하며 실행 결과 3스트라이크를 맞춘 도전 횟수를 출력
//3) Scanner를 통해 입력한 세 수와 요구사항 1)에서 생성한 랜덤한 세 수를 비교하여 스트라이크와 볼을 결정한다.
// 4) 키보드로 입력한 수가 1)에서 만든 배열의 수와 일치하며 위치도 같다면 스트라이크,
// 수는 일치하지만 위치가 다르면 볼이다.
public class Test5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] baseball = new int[3];

        // 숫자 생성
        for(int i =0; i < baseball.length; i++){
            int ramdom = (int) (Math.random()*10);
            baseball[i] = ramdom;
            for (int j=0; j<i;j++){
                if(baseball[i] == baseball[j]){
                    i =-1;
                }
            }
        }

//        //만들어진 숫자 확인용
//        System.out.print("만들어진 숫자 : ");
//        System.out.println(Arrays.toString(baseball));



        int cnt = 0;
        boolean result = true;

        System.out.println("숫자를 정했습니다. 게임을 시작합니다.");
        while (result) {
            int ball =0;
            int str = 0;
            cnt ++;
            int a,b,c;
//            System.out.println("한자리 숫자를 연속 3회 입력하세요.");
            a = sc.nextInt();
            b = sc.nextInt();
            c = sc.nextInt();

            if (baseball[0] == a) {
                str++;
            } else if (baseball[1] == a || baseball[2] == a) {
                ball++;
            }
            if (baseball[1] == b) {
                str++;
            } else if (baseball[0] == b || baseball[2] == b) {
                ball++;
            }
            if (baseball[2] == c) {
                str++;
            } else if (baseball[0] == c || baseball[1] == c) {
                ball++;
            }

            System.out.println(cnt + " >> "+ a + " " + b + " " + c + " ");
            System.out.println(str + "스트라이크 " + ball + "볼");

             if(str ==3 ){
                 System.out.println(cnt +"회만에 정답을 맞췄습니다.");
                 result = false;
             }

        }

    }
}
